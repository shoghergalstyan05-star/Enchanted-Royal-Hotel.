-- READ-ONLY. Paste complete generated build/ReadOnlyAudit.lua into Command Bar.
-- Checks sources against the uploaded original and structural dependencies.
-- It does not require gameplay modules, create instances, contact DataStores, or edit anything.
local WS = game:GetService("Workspace")
local passes, warnings, failures = 0, 0, 0
local function pass(message) passes += 1; print("[ERH PASS] " .. message) end
local function warning(message) warnings += 1; warn("[ERH WARN] " .. message) end
local function fail(message) failures += 1; warn("[ERH FAIL] " .. message) end
local BASELINE = {
["ReplicatedStorage/HotelConfig"]=string.sub([=[!local Config = {}

-- TEST store is separate from your existing Stage 1/2 live data.
-- Do not switch to the production name until migration and backups are verified.
Config.DataStoreName = "ERH_Stage3_TEST_v1"
Config.PreviousDataStoreName = "PMFH_PlayerData_v1"
Config.EnableLegacyReadMigration = false
Config.DiamondRespawnSeconds = 60
Config.DailyReward = 60
Config.DailyCooldown = 24 * 60 * 60
Config.MaxLobbyDiamonds = 2
Config.MaxTotalActiveDiamonds = 14
Config.RoyalEggPrice = 750
Config.HatchDuration = 3.5

Config.DiamondTypes = {
	Pink   = {Value = 1,  Color = Color3.fromRGB(255, 128, 205)},
	Blue   = {Value = 5,  Color = Color3.fromRGB(102, 220, 255)},
	Purple = {Value = 10, Color = Color3.fromRGB(182, 131, 255)},
	Gold   = {Value = 25, Color = Color3.fromRGB(255, 221, 120)},
}

Config.RoomThemes = {
	Default = {Name="Default", Color=Color3.fromRGB(243, 219, 232)},
	Blush   = {Name="Blush",   Color=Color3.fromRGB(246, 188, 215)},
	Pearl   = {Name="Pearl",   Color=Color3.fromRGB(246, 236, 222)},
	Lavender= {Name="Lavender",Color=Color3.fromRGB(205, 183, 240)},
	Ocean   = {Name="Ocean",   Color=Color3.fromRGB(156, 223, 230)},
}

Config.Pets = {
	{Id="kitten", Name="Royal Kitten",       Rarity="Common",   Weight=40, Color=Color3.fromRGB(255,230,196)},
	{Id="butterfly", Name="Fairy Butterfly", Rarity="Uncommon", Weight=25, Color=Color3.fromRGB(209,179,255)},
	{Id="seahorse", Name="Mermaid Seahorse", Rarity="Rare",     Weight=18, Color=Color3.fromRGB(132,235,228)},
	{Id="unicorn", Name="Baby Unicorn",      Rarity="Epic",     Weight=12, Color=Color3.fromRGB(255,216,244)},
	{Id="dragon", Name="Baby Dragon",        Rarity="Legendary",Weight=5,  Color=Color3.fromRGB(190,130,255)},
}

-- Published R15 layered-clothing Accessory assets must be supplied separately.
-- The boutique refuses purchases of missing assets (no invisible paid dresses).
Config.Clothing = {
	{Id="rose_gown", Name="Rose Princess Gown", Slot="Dress", Price=80},
	{Id="sea_gown", Name="Pearl Mermaid Gown", Slot="Dress", Price=160},
	{Id="lilac_gown", Name="Fairy Dream Gown", Slot="Dress", Price=220},
	{Id="pearl_crown", Name="Pearl Crown", Slot="Crown", Price=65},
	{Id="fairy_wings", Name="Fairy Wings", Slot="Wings", Price=110},
}
function Config.GetClothing(id)
	for _, item in ipairs(Config.Clothing) do if item.Id == id then return item end end
end

Config.TeleportPoints = {
	Lobby = "LobbySpawn",
	Spa = "SpaSpawn",
	Cafe = "CafeSpawn",
	Pool = "PoolSpawn",
	Ballroom = "BallroomSpawn",
	Nursery = "NurserySpawn",
	Boutique = "BoutiqueSpawn",
}

function Config.GetPet(id)
	for _, pet in ipairs(Config.Pets) do
		if pet.Id == id then return pet end
	end
end

function Config.RollPet(randomObj)
	local total = 0
	for _, pet in ipairs(Config.Pets) do total += pet.Weight end
	local roll = (randomObj or Random.new()):NextNumber(0, total)
	local acc = 0
	for _, pet in ipairs(Config.Pets) do
		acc += pet.Weight
		if roll <= acc then return pet end
	end
	return Config.Pets[#Config.Pets]
end

return Config]=], 2),
["ServerScriptService/HotelBootstrap"]=string.sub([=[!local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local Config = require(ReplicatedStorage:WaitForChild("HotelConfig"))
local DataServiceClass = require(script.Parent.Modules:WaitForChild("DataService"))
local DiamondServiceClass = require(script.Parent.Modules:WaitForChild("DiamondService"))
local RoomServiceClass = require(script.Parent.Modules:WaitForChild("RoomService"))
local EggServiceClass = require(script.Parent.Modules:WaitForChild("EggService"))
local BoutiqueClass = require(script.Parent.Modules:WaitForChild("BoutiqueService"))
local AmenityClass = require(script.Parent.Modules:WaitForChild("AmenityService"))

local remotes = ReplicatedStorage:FindFirstChild("ERH_Remotes") or Instance.new("Folder")
remotes.Name = "ERH_Remotes"
remotes.Parent = ReplicatedStorage
local Request = remotes:FindFirstChild("Request") or Instance.new("RemoteEvent")
Request.Name = "Request"
Request.Parent = remotes
local State = remotes:FindFirstChild("State") or Instance.new("RemoteEvent")
State.Name = "State"
State.Parent = remotes

local DataService = DataServiceClass.new()
local DiamondService = DiamondServiceClass.new(DataService, State)
local RoomService = RoomServiceClass.new(DataService, State)
local EggService = EggServiceClass.new(DataService, State)
local Boutique = BoutiqueClass.new(DataService, State)
local Amenity = AmenityClass.new(State)

DataService:BindAutosave()

local function ensureTestMap()
	local map = Workspace:FindFirstChild("RoyalHotelMap")
	if map then return map end

	map = Instance.new("Folder")
	map.Name = "RoyalHotelMap"
	map.Parent = Workspace

	local floor = Instance.new("Part")
	floor.Name = "TestFloor"
	floor.Size = Vector3.new(140, 1, 140)
	floor.Anchored = true
	floor.Position = Vector3.new(0, 0, 0)
	floor.Color = Color3.fromRGB(246, 231, 238)
	floor.Material = Enum.Material.Marble
	floor.Parent = map

	local lobby = Instance.new("Part")
	lobby.Name = "LobbySpawn"
	lobby.Anchored = true
	lobby.Transparency = 1
	lobby.CanCollide = false
	lobby.Position = Vector3.new(0, 4, 0)
	lobby.Parent = map

	for i, name in ipairs({"SpaSpawn","CafeSpawn","PoolSpawn","BallroomSpawn","NurserySpawn","BoutiqueSpawn"}) do
		local p = lobby:Clone()
		p.Name = name
		p.Position = Vector3.new(-35 + i*12, 4, -20)
		p.Parent = map
	end

	local diamondFolder = Instance.new("Folder")
	diamondFolder.Name = "DiamondSpawns"
	diamondFolder.Parent = map
	local placements = {
		{Vector3.new(0,1,8),"Pink","Lobby"},{Vector3.new(5,1,8),"Pink","Lobby"},{Vector3.new(-5,1,8),"Blue","Lobby"},{Vector3.new(9,1,8),"Purple","Lobby"},
		{Vector3.new(20,1,18),"Pink","Garden"},{Vector3.new(-18,1,22),"Blue","Garden"},{Vector3.new(26,1,-20),"Purple","Garden"},{Vector3.new(-28,1,-16),"Gold","Secret"}
	}
	for idx, info in ipairs(placements) do
		local s = Instance.new("Part")
		s.Name = string.format("Spawn_%02d", idx)
		s.Size = Vector3.new(1,1,1)
		s.Anchored = true
		s.Transparency = 1
		s.CanCollide = false
		s.Position = info[1]
		s:SetAttribute("DiamondType", info[2])
		s:SetAttribute("Area", info[3])
		s.Parent = diamondFolder
	end

	local roomsFolder = Instance.new("Folder")
	roomsFolder.Name = "Rooms"
	roomsFolder.Parent = map
	for i, wing in ipairs({"Princess","Mermaid","Fairy"}) do
		local model = Instance.new("Model")
		model.Name = wing .. "101"
		model:SetAttribute("Wing", wing)
		model:SetAttribute("RoomId", wing:sub(1,1) .. "101")
		model.Parent = roomsFolder
		local claimStand = Instance.new("Part")
		claimStand.Name = "ClaimPrompt"
		claimStand.Size = Vector3.new(1,2,1)
		claimStand.Anchored = true
		claimStand.Position = Vector3.new(-20 + i*12, 2, 24)
		claimStand.Parent = model
		local door = Instance.new("Part")
		door.Name = "Door"
		door.Size = Vector3.new(4,7,0.6)
		door.Anchored = true
		door.Position = Vector3.new(-20 + i*12, 3.5, 28)
		door.Color = Color3.fromRGB(238,205,222)
		door.Parent = model
		local spawn = Instance.new("Part")
		spawn.Name = "InteriorSpawn"
		spawn.Anchored = true
		spawn.Transparency = 1
		spawn.CanCollide = false
		spawn.Position = Vector3.new(-20 + i*12, 3, 34)
		spawn.Parent = model
		local decor = Instance.new("Part")
		decor.Name = "DecorPanel"
		decor.Size = Vector3.new(2,2,0.5)
		decor.Anchored = true
		decor.Position = Vector3.new(-18 + i*12, 3, 34)
		decor.Color = Color3.fromRGB(243, 219, 232)
		decor.Parent = model
	end

	local nursery = Instance.new("Part")
	nursery.Name = "EggNurseryPrompt"
	nursery.Size = Vector3.new(4,4,4)
	nursery.Anchored = true
	nursery.Position = Vector3.new(22,2,0)
	nursery.Color = Color3.fromRGB(255, 224, 240)
	nursery.Parent = map
	local eggPrompt = Instance.new("ProximityPrompt")
	eggPrompt.ActionText = "Open Nursery"
	eggPrompt.ObjectText = "Royal Eggs"
	eggPrompt.MaxActivationDistance = 10
	eggPrompt.RequiresLineOfSight = false
	eggPrompt.Parent = nursery
	nursery:SetAttribute("Interaction", "OpenNursery")

	return map
end

local mapFolder = ensureTestMap()
DiamondService:BindWorld(mapFolder)
RoomService:BindWorld(mapFolder)
Amenity:BindWorld(mapFolder)

for _, descendant in ipairs(mapFolder:GetDescendants()) do
	if descendant:IsA("BasePart") and descendant:GetAttribute("Interaction") == "OpenNursery" then
		local prompt = descendant:FindFirstChildWhichIsA("ProximityPrompt")
		if prompt then
			prompt.Triggered:Connect(function(player)
				State:FireClient(player, "OpenNursery")
			end)
		end
	end
end

local function snapshotPlayer(player)
	local profile = DataService:Get(player)
	if not profile then return end
	State:FireClient(player, "ProfileSnapshot", {
		Diamonds = profile.Diamonds,
		LastDaily = profile.LastDaily,
		Eggs = profile.Eggs,
		PetsOwned = profile.PetsOwned,
		EquippedPet = profile.EquippedPet,
		RoomTheme = profile.RoomTheme,
	})
end

Players.PlayerAdded:Connect(function(player)
	DataService:LoadPlayer(player)
	player.CharacterAdded:Connect(function()
		task.wait(0.6)
		EggService:RespawnEquippedPet(player)
		Boutique:Apply(player)
		local spawnPart = mapFolder:FindFirstChild("LobbySpawn")
		if spawnPart and player.Character then
			player.Character:PivotTo(spawnPart.CFrame + Vector3.new(0,3,0))
		end
	end)
	snapshotPlayer(player)
	Boutique:Sync(player)
end)

Players.PlayerRemoving:Connect(function(player)
	RoomService:PlayerRemoving(player)
	EggService:PlayerRemoving(player)
end)

local lastRequest = {}
Request.OnServerEvent:Connect(function(player, action, payload)
	if type(action) ~= "string" or #action > 32 then return end
	local profile = DataService:Get(player)
	if not profile then return end
	local nowClock=os.clock()
	local previous=lastRequest[player]
	if previous and nowClock - previous < 0.15 then return end
	lastRequest[player]=nowClock
	if action == "ClaimDaily" then
		local now = os.time()
		if now - profile.LastDaily >= Config.DailyCooldown then
			profile.LastDaily = now
			DataService:AddDiamonds(player, Config.DailyReward)
			State:FireClient(player, "Notice", "+" .. Config.DailyReward .. " diamonds")
			snapshotPlayer(player)
		else
			State:FireClient(player, "Notice", "Daily reward is not ready yet")
		end
	elseif action == "BuyEgg" then
		local ok, msg = EggService:BuyEgg(player)
		State:FireClient(player, "Notice", msg)
		snapshotPlayer(player)
	elseif action == "HatchEgg" then
		local ok, msg = EggService:HatchEgg(player)
		State:FireClient(player, "Notice", msg)
		snapshotPlayer(player)
	elseif action == "EquipPet" then
		if payload ~= nil and type(payload)~="table" then return end
		local petId = payload and payload.PetId or nil
		if petId ~= nil and (type(petId)~="string" or #petId>40) then return end
		local ok, msg = EggService:EquipPet(player, petId)
		State:FireClient(player, "Notice", msg)
		snapshotPlayer(player)
	elseif action == "CheckoutRoom" then
		RoomService:Checkout(player)
	elseif action == "RequestSnapshot" then
		snapshotPlayer(player)
		RoomService:_send(player)
		Boutique:Sync(player)
	elseif action == "BuyClothing" then
		if type(payload)~="string" or #payload>40 then return end
		local _,msg=Boutique:Buy(player,payload)
		State:FireClient(player,"Notice",msg)
		snapshotPlayer(player)
	elseif action == "EquipClothing" then
		if type(payload)~="string" or #payload>40 then return end
		local _,msg=Boutique:Equip(player,payload)
		State:FireClient(player,"Notice",msg)
	elseif action == "Teleport" then
		if type(payload) ~= "string" or #payload > 20 then return end
		local partName=Config.TeleportPoints[payload]
		local point=partName and mapFolder:FindFirstChild(partName)
		local root=player.Character and player.Character:FindFirstChild("HumanoidRootPart")
		if point and point:IsA("BasePart") and root then
			player.Character:PivotTo(point.CFrame + Vector3.new(0,3.5,0))
		end
	end
end)
Players.PlayerRemoving:Connect(function(player) lastRequest[player]=nil end)
]=], 2),
["StarterPlayer/StarterPlayerScripts/ClientMain"]=string.sub([=[!local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Config = require(ReplicatedStorage:WaitForChild("HotelConfig"))
local RunService = game:GetService("RunService")
local player = Players.LocalPlayer
local remotes = ReplicatedStorage:WaitForChild("ERH_Remotes")
local Request = remotes:WaitForChild("Request")
local State = remotes:WaitForChild("State")

local state = {Diamonds=0, Eggs=0, PetsOwned={}, EquippedPet=nil, Room=nil, Owned={}, Equipped={}, Catalog={}}

local previous=player:WaitForChild("PlayerGui"):FindFirstChild("RoyalHotelUI")
if previous then previous:Destroy() end
local gui = Instance.new("ScreenGui")
gui.Name = "RoyalHotelUI"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")
local uiScale=Instance.new("UIScale")
uiScale.Parent=gui
local function resizeUI()
	local camera=workspace.CurrentCamera
	if camera then
		local size=camera.ViewportSize
		uiScale.Scale=math.clamp(math.min(size.X/1000,size.Y/700),0.58,1)
	end
end
resizeUI()
workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(resizeUI)

local function ui(class, parent, props)
	local obj = Instance.new(class)
	for k,v in pairs(props or {}) do obj[k]=v end
	obj.Parent = parent
	return obj
end

local top = ui("Frame", gui, {AnchorPoint=Vector2.new(0.5,0), Position=UDim2.fromScale(0.5,0.03), Size=UDim2.fromOffset(520,58), BackgroundColor3=Color3.fromRGB(47,33,63), BackgroundTransparency=0.12})
ui("UICorner", top, {CornerRadius=UDim.new(0,18)})
local diamondsLabel = ui("TextLabel", top, {BackgroundTransparency=1, Size=UDim2.fromOffset(160,58), Position=UDim2.fromOffset(16,0), Text="Diamonds: 0", Font=Enum.Font.GothamBold, TextSize=22, TextColor3=Color3.fromRGB(255,236,250)})
local eggsLabel = ui("TextLabel", top, {BackgroundTransparency=1, Size=UDim2.fromOffset(120,58), Position=UDim2.fromOffset(190,0), Text="Eggs: 0", Font=Enum.Font.GothamBold, TextSize=22, TextColor3=Color3.fromRGB(255,236,250)})
local roomLabel = ui("TextLabel", top, {BackgroundTransparency=1, Size=UDim2.fromOffset(130,58), Position=UDim2.fromOffset(315,0), Text="Room: None", Font=Enum.Font.GothamBold, TextSize=18, TextColor3=Color3.fromRGB(255,236,250)})
local dailyBtn = ui("TextButton", top, {Size=UDim2.fromOffset(60,38), Position=UDim2.fromOffset(450,10), Text="Daily", Font=Enum.Font.GothamBold, TextSize=16, BackgroundColor3=Color3.fromRGB(232,182,214), TextColor3=Color3.fromRGB(80,40,80)})
ui("UICorner", dailyBtn, {CornerRadius=UDim.new(0,14)})

local notice = ui("TextLabel", gui, {AnchorPoint=Vector2.new(0.5,0), Position=UDim2.fromScale(0.5,0.11), Size=UDim2.fromOffset(420,40), BackgroundColor3=Color3.fromRGB(79,52,92), BackgroundTransparency=0.18, Text="", Font=Enum.Font.GothamSemibold, TextSize=20, TextColor3=Color3.fromRGB(255,248,253), Visible=false})
ui("UICorner", notice, {CornerRadius=UDim.new(0,14)})

local actions = ui("Frame", gui, {AnchorPoint=Vector2.new(1,1), Position=UDim2.fromScale(0.97,0.95), Size=UDim2.fromOffset(170,140), BackgroundColor3=Color3.fromRGB(52,38,68), BackgroundTransparency=0.12})
ui("UICorner", actions, {CornerRadius=UDim.new(0,16)})
local eggsBtn = ui("TextButton", actions, {Size=UDim2.fromOffset(140,36), Position=UDim2.fromOffset(15,14), Text="Royal Eggs", Font=Enum.Font.GothamBold, TextSize=18, BackgroundColor3=Color3.fromRGB(242,192,225), TextColor3=Color3.fromRGB(81,39,80)})
local petsBtn = ui("TextButton", actions, {Size=UDim2.fromOffset(140,36), Position=UDim2.fromOffset(15,56), Text="My Pets", Font=Enum.Font.GothamBold, TextSize=18, BackgroundColor3=Color3.fromRGB(241,230,244), TextColor3=Color3.fromRGB(81,39,80)})
local checkoutBtn = ui("TextButton", actions, {Size=UDim2.fromOffset(140,36), Position=UDim2.fromOffset(15,98), Text="Check Out", Font=Enum.Font.GothamBold, TextSize=18, BackgroundColor3=Color3.fromRGB(241,230,244), TextColor3=Color3.fromRGB(81,39,80)})
for _, b in ipairs({eggsBtn,petsBtn,checkoutBtn}) do ui("UICorner", b, {CornerRadius=UDim.new(0,12)}) end

local nurseryFrame = ui("Frame", gui, {AnchorPoint=Vector2.new(0.5,0.5), Position=UDim2.fromScale(0.5,0.58), Size=UDim2.fromOffset(520,360), BackgroundColor3=Color3.fromRGB(255,241,247), Visible=false})
ui("UICorner", nurseryFrame, {CornerRadius=UDim.new(0,18)})
ui("TextLabel", nurseryFrame, {BackgroundTransparency=1, Size=UDim2.fromOffset(300,40), Position=UDim2.fromOffset(20,14), Text="Royal Egg Nursery", Font=Enum.Font.Garamond, TextSize=32, TextColor3=Color3.fromRGB(103,58,102)})
local closeNursery = ui("TextButton", nurseryFrame, {Size=UDim2.fromOffset(40,32), Position=UDim2.fromOffset(468,14), Text="X", Font=Enum.Font.GothamBold, TextSize=18, BackgroundColor3=Color3.fromRGB(235,203,220), TextColor3=Color3.fromRGB(90,55,90)})
ui("UICorner", closeNursery, {CornerRadius=UDim.new(0,12)})
local buyEggBtn = ui("TextButton", nurseryFrame, {Size=UDim2.fromOffset(160,42), Position=UDim2.fromOffset(30,80), Text="Buy Egg • " .. tostring(Config.RoyalEggPrice) .. " 💎", Font=Enum.Font.GothamBold, TextSize=18, BackgroundColor3=Color3.fromRGB(243,197,226), TextColor3=Color3.fromRGB(78,42,78)})
local hatchEggBtn = ui("TextButton", nurseryFrame, {Size=UDim2.fromOffset(160,42), Position=UDim2.fromOffset(200,80), Text="Hatch Egg", Font=Enum.Font.GothamBold, TextSize=18, BackgroundColor3=Color3.fromRGB(235,226,244), TextColor3=Color3.fromRGB(78,42,78)})
for _, b in ipairs({buyEggBtn,hatchEggBtn}) do ui("UICorner", b, {CornerRadius=UDim.new(0,12)}) end
local odds = ui("TextLabel", nurseryFrame, {BackgroundTransparency=1, Size=UDim2.fromOffset(460,85), Position=UDim2.fromOffset(30,138), TextXAlignment=Enum.TextXAlignment.Left, TextYAlignment=Enum.TextYAlignment.Top, TextWrapped=true, Text="Egg odds: Kitten 40%, Butterfly 25%, Seahorse 18%, Unicorn 12%, Dragon 5%.\nEach egg hatches exactly one random pet.", Font=Enum.Font.Gotham, TextSize=18, TextColor3=Color3.fromRGB(98,70,98)})
local petList = ui("ScrollingFrame", nurseryFrame, {Size=UDim2.fromOffset(460,100), Position=UDim2.fromOffset(30,238), CanvasSize=UDim2.fromOffset(0,0), ScrollBarThickness=8, BackgroundColor3=Color3.fromRGB(250,248,251)})
ui("UICorner", petList, {CornerRadius=UDim.new(0,12)})
local petLayout = ui("UIListLayout", petList, {Padding=UDim.new(0,8), FillDirection=Enum.FillDirection.Horizontal, SortOrder=Enum.SortOrder.LayoutOrder})

local hatchOverlay = ui("Frame", gui, {Size=UDim2.fromScale(1,1), BackgroundColor3=Color3.fromRGB(40,20,50), BackgroundTransparency=0.25, Visible=false})
local hatchText = ui("TextLabel", hatchOverlay, {AnchorPoint=Vector2.new(0.5,0.5), Position=UDim2.fromScale(0.5,0.72), Size=UDim2.fromOffset(450,105), TextWrapped=true, BackgroundTransparency=1, Text="", Font=Enum.Font.Garamond, TextSize=38, TextColor3=Color3.fromRGB(255,240,251)})
-- 3D cosmetic egg preview. This is basic procedurally made ART PLACEHOLDER, not a final mesh.
local viewport = ui("ViewportFrame", hatchOverlay, {AnchorPoint=Vector2.new(0.5,0.5), Position=UDim2.fromScale(0.5,0.38), Size=UDim2.fromOffset(300,300), BackgroundTransparency=1, Ambient=Color3.fromRGB(250,220,247), LightColor=Color3.fromRGB(255,238,206), LightDirection=Vector3.new(-1,-1,-1)})
local scene = ui("WorldModel",viewport,{})
local egg=ui("Part",scene,{Name="RoyalEggPreview",Size=Vector3.new(2.3,2.3,2.3),Anchored=true,CanCollide=false,Color=Color3.fromRGB(253,226,249),Material=Enum.Material.Glass})
ui("SpecialMesh",egg,{MeshType=Enum.MeshType.Sphere,Scale=Vector3.new(1,1.4,1)})
local crownBand=ui("Part",scene,{Size=Vector3.new(2.65,0.23,2.65),Anchored=true,CanCollide=false,Material=Enum.Material.Metal,Color=Color3.fromRGB(255,211,114)})
local camera=ui("Camera",viewport,{CFrame=CFrame.lookAt(Vector3.new(0,1,8),Vector3.new(0,0,0)),FieldOfView=35})
viewport.CurrentCamera=camera
RunService.RenderStepped:Connect(function()
	if not hatchOverlay.Visible then return end
	local t=os.clock()
	local angle=math.sin(t*7)*0.15
	egg.CFrame=CFrame.new(0,math.sin(t*5)*0.13,0)*CFrame.Angles(0,t*0.9,angle)
	crownBand.CFrame=CFrame.new(0,math.sin(t*5)*0.13,0)*CFrame.Angles(0,t*0.9,angle)
end)

local function showNotice(msg)
	notice.Text = msg
	notice.Visible = true
	task.delay(2.5, function()
		if notice.Text == msg then notice.Visible = false end
	end)
end

local function rebuildPetList()
	for _, child in ipairs(petList:GetChildren()) do
		if child:IsA("Frame") then child:Destroy() end
	end
	for i, petId in ipairs(state.PetsOwned) do
		local row = ui("Frame", petList, {Size=UDim2.fromOffset(150,80), BackgroundColor3=Color3.fromRGB(244,231,242)})
		ui("UICorner", row, {CornerRadius=UDim.new(0,12)})
		ui("TextLabel", row, {BackgroundTransparency=1, Size=UDim2.fromOffset(140,26), Position=UDim2.fromOffset(8,8), Text=petId, Font=Enum.Font.GothamBold, TextSize=16, TextColor3=Color3.fromRGB(84,52,84)})
		local equip = ui("TextButton", row, {Size=UDim2.fromOffset(128,26), Position=UDim2.fromOffset(10,44), Text=(state.EquippedPet == petId and "Unequip" or "Equip"), Font=Enum.Font.GothamBold, TextSize=15, BackgroundColor3=Color3.fromRGB(236,194,222), TextColor3=Color3.fromRGB(84,52,84)})
		ui("UICorner", equip, {CornerRadius=UDim.new(0,10)})
		equip.MouseButton1Click:Connect(function()
			if state.EquippedPet == petId then
				Request:FireServer("EquipPet", {PetId = nil})
			else
				Request:FireServer("EquipPet", {PetId = petId})
			end
		end)
	end
	task.wait()
	petList.CanvasSize = UDim2.fromOffset(math.max(0, petLayout.AbsoluteContentSize.X + 20), 0)
end

local boutiqueFrame
local boutiqueList
local function buildBoutique()
	if not boutiqueFrame or not boutiqueList then return end
	for _, child in ipairs(boutiqueList:GetChildren()) do
		if child:IsA("Frame") then child:Destroy() end
	end
	for i,item in ipairs(state.Catalog or {}) do
		local row=ui("Frame",boutiqueList,{Size=UDim2.new(1,-12,0,78),BackgroundColor3=Color3.fromRGB(248,232,245),LayoutOrder=i})
		ui("UICorner",row,{CornerRadius=UDim.new(0,11)})
		ui("TextLabel",row,{Size=UDim2.new(0.62,0,0,35),Position=UDim2.fromOffset(8,4),BackgroundTransparency=1,Text=item.Name,TextXAlignment=Enum.TextXAlignment.Left,Font=Enum.Font.GothamBold,TextSize=15,TextColor3=Color3.fromRGB(80,47,85)})
		local text
		if not item.Ready then text="3D asset needed"
		elseif state.Owned[item.Id] then text=state.Equipped[item.Slot]==item.Id and "Unequip" or "Equip"
		else text="Buy • "..item.Price.." diamonds" end
		local button=ui("TextButton",row,{Position=UDim2.new(0.62,0,0,9),Size=UDim2.new(0.37,0,0,58),Text=text,TextWrapped=true,Font=Enum.Font.GothamBold,TextSize=14,BackgroundColor3=Color3.fromRGB(228,191,221),TextColor3=Color3.fromRGB(78,44,82)})
		ui("UICorner",button,{CornerRadius=UDim.new(0,10)})
		button.MouseButton1Click:Connect(function()
			if not item.Ready then showNotice("Upload the 3D clothing asset first") return end
			Request:FireServer(state.Owned[item.Id] and "EquipClothing" or "BuyClothing",item.Id)
		end)
		ui("TextLabel",row,{Size=UDim2.new(0.6,0,0,20),Position=UDim2.fromOffset(8,43),BackgroundTransparency=1,Text=item.Slot,TextXAlignment=Enum.TextXAlignment.Left,Font=Enum.Font.Gotham,TextSize=12,TextColor3=Color3.fromRGB(122,88,119)})
	end
	local layout=boutiqueList:FindFirstChildOfClass("UIListLayout")
	if layout then boutiqueList.CanvasSize=UDim2.fromOffset(0,layout.AbsoluteContentSize.Y+20) end
end

local function refreshTop()
	diamondsLabel.Text = "Diamonds: " .. tostring(state.Diamonds or 0)
	eggsLabel.Text = "Eggs: " .. tostring(state.Eggs or 0)
	roomLabel.Text = "Room: " .. (state.Room and state.Room.Id or "None")
end

closeNursery.MouseButton1Click:Connect(function() nurseryFrame.Visible = false end)
eggsBtn.MouseButton1Click:Connect(function() nurseryFrame.Visible = not nurseryFrame.Visible end)
petsBtn.MouseButton1Click:Connect(function() nurseryFrame.Visible = true end)
checkoutBtn.MouseButton1Click:Connect(function() Request:FireServer("CheckoutRoom") end)
dailyBtn.MouseButton1Click:Connect(function() Request:FireServer("ClaimDaily") end)
buyEggBtn.MouseButton1Click:Connect(function() Request:FireServer("BuyEgg") end)
hatchEggBtn.MouseButton1Click:Connect(function() Request:FireServer("HatchEgg") end)

State.OnClientEvent:Connect(function(kind, payload)
	if kind == "ProfileSnapshot" then
		for k, v in pairs(payload) do state[k] = v end
		refreshTop(); rebuildPetList()
	elseif kind == "BoutiqueCatalog" then
		state.Catalog=payload; buildBoutique()
	elseif kind == "BoutiqueOwnership" then
		state.Owned=payload; buildBoutique()
	elseif kind == "BoutiqueEquipped" then
		state.Equipped=payload; buildBoutique()
	elseif kind == "EggsSnapshot" then
		state.Eggs = payload.Eggs
		state.PetsOwned = payload.PetsOwned
		state.EquippedPet = payload.EquippedPet
		refreshTop(); rebuildPetList()
	elseif kind == "RoomSnapshot" then
		state.Room = payload
		refreshTop()
	elseif kind == "Notice" then
		showNotice(payload)
	elseif kind == "DiamondBurst" then
		state.Diamonds += payload
		refreshTop()
		showNotice("+" .. tostring(payload) .. " diamonds")
	elseif kind == "OpenNursery" then
		nurseryFrame.Visible = true
	elseif kind == "EggHatching" then
		hatchOverlay.Visible = true
		hatchText.Text = "Your Royal Egg is hatching..."
	elseif kind == "EggResult" then
		hatchText.Text = "You hatched: " .. payload.Name .. "\n" .. payload.Rarity
		task.delay(2.2, function() hatchOverlay.Visible = false end)
	end
end)


-- Map navigation points must correspond to parts named in Workspace/RoyalHotelMap.
local mapButton=ui("TextButton", gui, {AnchorPoint=Vector2.new(0,1),Position=UDim2.fromScale(0.03,0.95), Size=UDim2.fromOffset(148,40),Text="Royal Map",Font=Enum.Font.GothamBold,TextSize=17,BackgroundColor3=Color3.fromRGB(232,194,219),TextColor3=Color3.fromRGB(68,39,70)})
ui("UICorner",mapButton,{CornerRadius=UDim.new(0,13)})
local mapPanel=ui("Frame",gui,{AnchorPoint=Vector2.new(0,1),Position=UDim2.fromScale(0.03,0.87),Size=UDim2.fromOffset(170,302),BackgroundColor3=Color3.fromRGB(255,240,249),Visible=false})
ui("UICorner",mapPanel,{CornerRadius=UDim.new(0,14)})
mapButton.MouseButton1Click:Connect(function() mapPanel.Visible=not mapPanel.Visible end)
for i,dest in ipairs({"Lobby","Spa","Cafe","Pool","Ballroom","Nursery","Boutique"}) do
	local button=ui("TextButton",mapPanel,{Size=UDim2.fromOffset(150,35),Position=UDim2.fromOffset(10,8+(i-1)*42),Text=dest,Font=Enum.Font.GothamSemibold,TextSize=16,BackgroundColor3=Color3.fromRGB(242,211,233),TextColor3=Color3.fromRGB(75,45,78)})
	ui("UICorner",button,{CornerRadius=UDim.new(0,9)})
	button.MouseButton1Click:Connect(function()
		Request:FireServer("Teleport",dest)
		mapPanel.Visible=false
	end)
end
-- Request a snapshot after connecting handlers so the initial RemoteEvent cannot be missed.
Request:FireServer("RequestSnapshot")

-- Wardrobe / boutique. Clothing is purchasable only after a valid Accessory is imported.
local boutiqueButton=ui("TextButton",gui,{AnchorPoint=Vector2.new(1,1),Position=UDim2.fromScale(0.97,0.72),Size=UDim2.fromOffset(170,42),Text="Royal Boutique",Font=Enum.Font.GothamBold,TextSize=17,BackgroundColor3=Color3.fromRGB(250,212,235),TextColor3=Color3.fromRGB(70,43,73)})
ui("UICorner",boutiqueButton,{CornerRadius=UDim.new(0,13)})
boutiqueFrame=ui("Frame",gui,{AnchorPoint=Vector2.new(0.5,0.5),Position=UDim2.fromScale(0.5,0.5),Size=UDim2.fromOffset(500,440),BackgroundColor3=Color3.fromRGB(255,242,250),Visible=false})
ui("UICorner",boutiqueFrame,{CornerRadius=UDim.new(0,18)})
ui("TextLabel",boutiqueFrame,{Position=UDim2.fromOffset(20,10),Size=UDim2.fromOffset(310,46),Text="Royal Boutique",BackgroundTransparency=1,Font=Enum.Font.Garamond,TextSize=34,TextColor3=Color3.fromRGB(91,51,88)})
local closeBoutique=ui("TextButton",boutiqueFrame,{Position=UDim2.fromOffset(451,17),Size=UDim2.fromOffset(32,32),Text="X",BackgroundColor3=Color3.fromRGB(238,213,228),TextColor3=Color3.fromRGB(75,47,80)})
ui("UICorner",closeBoutique,{CornerRadius=UDim.new(0,10)})
closeBoutique.MouseButton1Click:Connect(function() boutiqueFrame.Visible=false end)
boutiqueButton.MouseButton1Click:Connect(function() boutiqueFrame.Visible=not boutiqueFrame.Visible end)
ui("TextLabel",boutiqueFrame,{Position=UDim2.fromOffset(20,57),Size=UDim2.fromOffset(455,45),Text="3D clothing appears here once its wearable Accessory is imported. No payment for invisible items.",TextWrapped=true,BackgroundTransparency=1,Font=Enum.Font.Gotham,TextSize=14,TextColor3=Color3.fromRGB(121,82,117)})
boutiqueList=ui("ScrollingFrame",boutiqueFrame,{Position=UDim2.fromOffset(20,112),Size=UDim2.fromOffset(460,300),CanvasSize=UDim2.fromOffset(0,0),ScrollBarThickness=6,BackgroundColor3=Color3.fromRGB(255,249,253)})
ui("UIListLayout",boutiqueList,{Padding=UDim.new(0,8),SortOrder=Enum.SortOrder.LayoutOrder})
buildBoutique()
]=], 2),
["ServerScriptService/Modules/DataService"]=string.sub([=[!-- DataService: server-owned session data with safe defaults and failed-load protection.
-- Not a production-grade cross-server session-locking solution; see Docs/RELEASE_CHECKLIST.md.
local Players = game:GetService("Players")
local DSS = game:GetService("DataStoreService")
local RS = game:GetService("ReplicatedStorage")
local Config = require(RS:WaitForChild("HotelConfig"))
local DataService = {}
DataService.__index = DataService

local function validInt(n, max)
	if type(n) ~= "number" or n ~= n or n == math.huge or n == -math.huge then return nil end
	return math.floor(math.clamp(n, 0, max))
end

function DataService.new()
	local ok, store = pcall(function() return DSS:GetDataStore(Config.DataStoreName) end)
	if not ok then warn("DataStore not available in this place; UNSAVED test sessions only:",store) end
	local legacy = nil
	if Config.EnableLegacyReadMigration then
		local legacyOk, legacyStore = pcall(function() return DSS:GetDataStore(Config.PreviousDataStoreName) end)
		if legacyOk then legacy=legacyStore else warn("Legacy DataStore unavailable",legacyStore) end
	end
	return setmetatable({
		_store = ok and store or nil,
		_legacy = legacy,
		_profiles = {},
		_saving = {},
	}, DataService)
end

function DataService:DefaultProfile()
	return {Diamonds=0, LastDaily=0, Eggs=0, PetsOwned={}, EquippedPet=nil, RoomTheme="Default", Owned={}, Equipped={}}
end

function DataService:_clean(raw)
	local d=self:DefaultProfile()
	if type(raw) ~= "table" then return d end
	d.Diamonds = validInt(raw.Diamonds, 1000000000) or 0
	d.LastDaily = validInt(raw.LastDaily, os.time()) or 0
	d.Eggs = validInt(raw.Eggs, 10000) or 0
	if type(raw.Owned)=="table" then
		for id, owned in pairs(raw.Owned) do
			if type(id)=="string" and owned==true and #id<=64 then d.Owned[id]=true end
		end
	end
	if type(raw.Equipped)=="table" then
		for slot, id in pairs(raw.Equipped) do
			if type(slot)=="string" and type(id)=="string" and #slot<=30 and #id<=64 then
				d.Equipped[slot]=id
			end
		end
	end
	local seen={}
	if type(raw.PetsOwned)=="table" then
		for _, id in ipairs(raw.PetsOwned) do
			if type(id)=="string" and Config.GetPet(id) then
				seen[id]=true; table.insert(d.PetsOwned,id)
			end
		end
	end
	-- Old Studio profiles stored pet ownership as Owned[petId]=true.
	for _, pet in ipairs(Config.Pets) do
		if d.Owned[pet.Id] and not seen[pet.Id] then
			seen[pet.Id]=true; table.insert(d.PetsOwned,pet.Id)
		end
	end
	if type(raw.EquippedPet)=="string" and seen[raw.EquippedPet] then
		d.EquippedPet=raw.EquippedPet
	elseif type(d.Equipped.Pet)=="string" and seen[d.Equipped.Pet] then
		d.EquippedPet=d.Equipped.Pet
	end
	if type(raw.RoomTheme)=="string" and Config.RoomThemes[raw.RoomTheme] then
		d.RoomTheme=raw.RoomTheme
	end
	return d
end

local function tryN(fn, attempts)
	local result, lastError
	for attempt=1,attempts do
		local ok, value = pcall(fn)
		if ok then return true,value end
		lastError = value
		if attempt < attempts then task.wait(attempt) end
	end
	return false,lastError
end

function DataService:LoadPlayer(player)
	if self._profiles[player] then return self._profiles[player] end
	local key="player_" .. player.UserId
	local ok, raw
	if self._store then
		ok, raw = tryN(function() return self._store:GetAsync(key) end, 3)
	else
		ok, raw = false, "Place is not published or DataStore access is not available"
	end
	local sessionOnly = not ok
	if ok and raw==nil and self._legacy then
		local migrated, old = tryN(function() return self._legacy:GetAsync(key) end, 3)
		if migrated then raw=old else sessionOnly=true; warn("Legacy load failed; protecting profile from overwrite:",old) end
	end
	if not ok then warn("Cannot load data: using UNSAVED session values for",player.Name,raw) end
	local profile=self:_clean(raw)
	profile.SessionOnly=sessionOnly
	self._profiles[player]=profile

	local stats=player:FindFirstChild("leaderstats") or Instance.new("Folder")
	stats.Name="leaderstats"; stats.Parent=player
	local diamonds=stats:FindFirstChild("Diamonds") or Instance.new("IntValue")
	diamonds.Name="Diamonds"; diamonds.Value=profile.Diamonds; diamonds.Parent=stats
	return profile
end

function DataService:Get(player) return self._profiles[player] end

function DataService:SetDiamonds(player, amount)
	local p=self._profiles[player]
	local valid=validInt(amount,1000000000)
	if not p or valid==nil then return false end
	p.Diamonds=valid
	local stats=player:FindFirstChild("leaderstats")
	local v=stats and stats:FindFirstChild("Diamonds")
	if v then v.Value=valid end
	return true
end

function DataService:AddDiamonds(player, amount)
	local p=self._profiles[player]
	local valid=validInt(math.abs(amount),1000000000)
	if not p or valid==nil or (amount < 0 and p.Diamonds < valid) then return false end
	return self:SetDiamonds(player,p.Diamonds+amount)
end

function DataService:SavePlayer(player)
	local profile=self._profiles[player]
	if not profile or profile.SessionOnly or not self._store then return false end
	if self._saving[player] then return false end
	self._saving[player]=true
	local payload={
		Diamonds=profile.Diamonds, LastDaily=profile.LastDaily, Eggs=profile.Eggs,
		PetsOwned=table.clone(profile.PetsOwned), EquippedPet=profile.EquippedPet,
		RoomTheme=profile.RoomTheme, Owned=table.clone(profile.Owned), Equipped=table.clone(profile.Equipped),
	}
	local ok, err = tryN(function()
		return self._store:UpdateAsync("player_"..player.UserId,function(old)
			-- Preserve unrecognised prior fields if upgrading an existing record.
			if type(old)=="table" then
				for k,v in pairs(old) do if payload[k]==nil and k~="EquippedPet" then payload[k]=v end end
			end
			return payload
		end)
	end,3)
	self._saving[player]=nil
	if not ok then warn("SAVE FAILED for",player.Name,err) end
	return ok
end

function DataService:RemovePlayer(player)
	-- Server callbacks do not save two different snapshots simultaneously.
	while self._saving[player] do task.wait(0.1) end
	self:SavePlayer(player)
	self._profiles[player]=nil
end

function DataService:BindAutosave()
	Players.PlayerRemoving:Connect(function(p) self:RemovePlayer(p) end)
	task.spawn(function()
		while true do
			task.wait(120)
			for p in pairs(self._profiles) do self:SavePlayer(p) end
		end
	end)
	game:BindToClose(function()
		local threads={}
		for p in pairs(self._profiles) do
			table.insert(threads,task.spawn(function() self:SavePlayer(p) end))
		end
		task.wait(3)
	end)
end
return DataService
]=], 2),
["ServerScriptService/Modules/DiamondService"]=string.sub([=[!local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Config = require(ReplicatedStorage:WaitForChild("HotelConfig"))

local DiamondService = {}
DiamondService.__index = DiamondService

local function buildDiamond(color, pos)
	local p = Instance.new("Part")
	p.Name = "Diamond"
	p.Anchored = true
	p.CanCollide = false
	p.Size = Vector3.new(1.2,1.2,1.2)
	p.Material = Enum.Material.Neon
	p.Color = color
	p.CFrame = CFrame.new(pos) * CFrame.Angles(0, math.rad(45), math.rad(45))
	p.Shape = Enum.PartType.Ball -- Clean orb until custom cut-diamond mesh is imported.
	local sparkle = Instance.new("Sparkles")
	sparkle.SparkleColor = color
	sparkle.Parent = p
	local prompt = Instance.new("ProximityPrompt")
	prompt.ActionText = "Collect"
	prompt.ObjectText = "Diamond"
	prompt.MaxActivationDistance = 8
	prompt.HoldDuration = 0
	prompt.RequiresLineOfSight = false
	prompt.Parent = p
	return p, prompt
end

function DiamondService.new(dataService, stateEvent)
	local self = setmetatable({}, DiamondService)
	self.DataService = dataService
	self.StateEvent = stateEvent
	self.Active = {}
	self.SpawnFolder = nil
	return self
end

function DiamondService:_notify(player, amount)
	self.StateEvent:FireClient(player, "DiamondBurst", amount)
end

function DiamondService:_createAtSpawn(spawnPart)
	local dtype = spawnPart:GetAttribute("DiamondType") or "Pink"
	local typeDef = Config.DiamondTypes[dtype]
	if not typeDef then return end
	local pos = spawnPart.Position + Vector3.new(0, 2.2, 0)
	local diamond, prompt = buildDiamond(typeDef.Color, pos)
	diamond.Parent = spawnPart.Parent
	self.Active[spawnPart] = diamond
	local function collect(player)
		if self.Active[spawnPart] ~= diamond or diamond.Parent == nil then return end
		local character = player.Character
		local hrp = character and character:FindFirstChild("HumanoidRootPart")
		if not hrp or (hrp.Position - diamond.Position).Magnitude > 12 then return end
		if not self.DataService:Get(player) then return end
		self.Active[spawnPart] = nil
		diamond:Destroy()
		if self.DataService:AddDiamonds(player, typeDef.Value) then
			self:_notify(player, typeDef.Value)
		end
		task.delay(Config.DiamondRespawnSeconds, function()
			if spawnPart.Parent then self:_createAtSpawn(spawnPart) end
		end)
	end
	prompt.Triggered:Connect(collect)
	diamond.Touched:Connect(function(hit)
		local player = game:GetService("Players"):GetPlayerFromCharacter(hit.Parent)
		if player then collect(player) end
	end)
end

function DiamondService:BindWorld(mapFolder)
	local spawns = mapFolder:FindFirstChild("DiamondSpawns")
	if not spawns then return end
	self.SpawnFolder = spawns

	local ordered = {}
	for _, part in ipairs(spawns:GetChildren()) do
		if part:IsA("BasePart") then table.insert(ordered, part) end
	end
	table.sort(ordered, function(a,b) return a.Name < b.Name end)

	local count = 0
	local lobbyCount = 0
	for _, spawn in ipairs(ordered) do
		if count >= Config.MaxTotalActiveDiamonds then break end
		local area = spawn:GetAttribute("Area") or ""
		if area == "Lobby" then
			if lobbyCount >= Config.MaxLobbyDiamonds then continue end
			lobbyCount += 1
		end
		count += 1
		self:_createAtSpawn(spawn)
	end
end

return DiamondService
]=], 2),
["ServerScriptService/Modules/EggService"]=string.sub([=[!local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Config = require(ReplicatedStorage:WaitForChild("HotelConfig"))
local PetFactory = require(script.Parent:WaitForChild("PetModelFactory"))

local EggService = {}
EggService.__index = EggService

function EggService.new(dataService, stateEvent)
	local self = setmetatable({}, EggService)
	self.DataService = dataService
	self.StateEvent = stateEvent
	self.ActivePets = {}
	self.Hatching = {}
	return self
end

function EggService:_snapshot(player)
	local p = self.DataService:Get(player)
	if not p then return end
	self.StateEvent:FireClient(player, "EggsSnapshot", {
		Eggs = p.Eggs,
		PetsOwned = p.PetsOwned,
		EquippedPet = p.EquippedPet,
	})
end

function EggService:BuyEgg(player)
	local p = self.DataService:Get(player)
	if not p then return false, "No profile" end
	if p.Diamonds < Config.RoyalEggPrice then return false, "Not enough diamonds" end
	self.DataService:AddDiamonds(player, -Config.RoyalEggPrice)
	p.Eggs += 1
	self:_snapshot(player)
	return true, "Royal Egg purchased"
end

function EggService:HatchEgg(player)
	local p = self.DataService:Get(player)
	if not p then return false, "No profile" end
	if self.Hatching[player] then return false, "An egg is already hatching" end
	if p.Eggs <= 0 then return false, "You do not own any eggs" end
	self.Hatching[player] = true
	p.Eggs -= 1
	local pet = Config.RollPet(Random.new())
	table.insert(p.PetsOwned, pet.Id)
	self.StateEvent:FireClient(player, "EggHatching", {Duration = Config.HatchDuration})
	task.delay(Config.HatchDuration, function()
		self.Hatching[player]=nil
		if not player.Parent or not self.DataService:Get(player) then return end
		self.StateEvent:FireClient(player, "EggResult", {Id = pet.Id, Name = pet.Name, Rarity = pet.Rarity})
		self:_snapshot(player)
	end)
	return true, "Your egg is hatching"
end

function EggService:_destroyPet(player)
	local model = self.ActivePets[player]
	if model then model:Destroy() end
	self.ActivePets[player] = nil
end

function EggService:_followLoop(player, model)
	task.spawn(function()
		local bob = 0
		while self.ActivePets[player] == model and player.Parent do
			local char = player.Character
			local hrp = char and char:FindFirstChild("HumanoidRootPart")
			if not hrp or not model.PrimaryPart then task.wait(0.1) continue end
			bob += 0.18
			local target = hrp.Position + Vector3.new(2.4, 1.7 + math.sin(bob)*0.25, 2.1)
			local current = model.PrimaryPart.Position
			local nextPos = current:Lerp(target, 0.18)
			model:PivotTo(CFrame.new(nextPos, hrp.Position))
			task.wait(0.05)
		end
	end)
end

function EggService:EquipPet(player, petId)
	local p = self.DataService:Get(player)
	if not p then return false, "No profile" end
	if petId ~= nil then
		local owns = false
		for _, id in ipairs(p.PetsOwned) do if id == petId then owns = true break end end
		if not owns then return false, "You do not own that pet" end
		p.EquippedPet = petId
	else
		p.EquippedPet = nil
	end
	self:_destroyPet(player)
	if p.EquippedPet then
		local petDef = Config.GetPet(p.EquippedPet)
		if petDef and player.Character and player.Character:FindFirstChild("HumanoidRootPart") then
			local model = PetFactory.CreatePetModel(petDef)
			model.Parent = workspace
			local hrp = player.Character.HumanoidRootPart
			model:PivotTo(hrp.CFrame * CFrame.new(2.5, 2, 2.2))
			self.ActivePets[player] = model
			self:_followLoop(player, model)
		end
	end
	self:_snapshot(player)
	return true, p.EquippedPet and "Pet equipped" or "Pet unequipped"
end

function EggService:RespawnEquippedPet(player)
	local p = self.DataService:Get(player)
	if p and p.EquippedPet then
		self:EquipPet(player, p.EquippedPet)
	end
end

function EggService:PlayerRemoving(player)
	self:_destroyPet(player)
	self.Hatching[player]=nil
end

return EggService]=], 2),
["ServerScriptService/Modules/RoomService"]=string.sub([=[!local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Config = require(ReplicatedStorage:WaitForChild("HotelConfig"))

local RoomService = {}
RoomService.__index = RoomService

function RoomService.new(dataService, stateEvent)
	local self = setmetatable({}, RoomService)
	self.DataService = dataService
	self.StateEvent = stateEvent
	self.Rooms = {}
	return self
end

function RoomService:BindWorld(mapFolder)
	local roomsFolder = mapFolder:FindFirstChild("Rooms")
	if not roomsFolder then return end
	for _, model in ipairs(roomsFolder:GetChildren()) do
		if model:IsA("Model") then
			local roomId = model:GetAttribute("RoomId") or model.Name
			local door = model:FindFirstChild("Door")
			local claim = model:FindFirstChild("ClaimPrompt")
			local spawn = model:FindFirstChild("InteriorSpawn")
			local decor = model:FindFirstChild("DecorPanel")
			if door and claim and spawn then
				self.Rooms[roomId] = {
					Id = roomId,
					Wing = model:GetAttribute("Wing") or "Princess",
					Occupant = nil,
					Model = model,
					Door = door,
					ClaimPrompt = claim,
					Spawn = spawn,
					Decor = decor,
					Open = false,
				}
				self:_wireRoom(self.Rooms[roomId])
			end
		end
	end
end

function RoomService:_currentRoom(player)
	for _, room in pairs(self.Rooms) do
		if room.Occupant == player then return room end
	end
end

function RoomService:_send(player)
	local room = self:_currentRoom(player)
	self.StateEvent:FireClient(player, "RoomSnapshot", room and {Id=room.Id, Wing=room.Wing} or nil)
end

function RoomService:_setDoor(room, open)
	room.Open = open
	room.Door.CanCollide = not open
	room.Door.Transparency = open and 0.6 or 0
end

function RoomService:_wireRoom(room)
	local claimPrompt = room.ClaimPrompt:FindFirstChildWhichIsA("ProximityPrompt") or Instance.new("ProximityPrompt")
	claimPrompt.ActionText = "Check In"
	claimPrompt.ObjectText = room.Id
	claimPrompt.MaxActivationDistance = 10
	claimPrompt.RequiresLineOfSight = false
	claimPrompt.Parent = room.ClaimPrompt
	claimPrompt.Triggered:Connect(function(player)
		self:ClaimRoom(player, room.Id)
	end)

	local doorPrompt = room.Door:FindFirstChildWhichIsA("ProximityPrompt") or Instance.new("ProximityPrompt")
	doorPrompt.ActionText = "Open / Close"
	doorPrompt.ObjectText = room.Id .. " Door"
	doorPrompt.MaxActivationDistance = 8
	doorPrompt.RequiresLineOfSight = false
	doorPrompt.Parent = room.Door
	doorPrompt.Triggered:Connect(function(player)
		self:ToggleDoor(player, room.Id)
	end)

	if room.Decor then
		local decorPrompt = room.Decor:FindFirstChildWhichIsA("ProximityPrompt") or Instance.new("ProximityPrompt")
		decorPrompt.ActionText = "Change Theme"
		decorPrompt.ObjectText = "Suite Decor"
		decorPrompt.MaxActivationDistance = 8
		decorPrompt.RequiresLineOfSight = false
		decorPrompt.Parent = room.Decor
		decorPrompt.Triggered:Connect(function(player)
			self:CycleTheme(player, room.Id)
		end)
	end
end

function RoomService:ClaimRoom(player, roomId)
	if self:_currentRoom(player) then
		self.StateEvent:FireClient(player, "Notice", "You already have a suite.")
		return false
	end
	local room = self.Rooms[roomId]
	if not room or room.Occupant then
		self.StateEvent:FireClient(player, "Notice", "That suite is unavailable.")
		return false
	end
	room.Occupant = player
	self:_setDoor(room, false)
	self:_send(player)
	self.StateEvent:FireClient(player, "Notice", "Welcome. You checked into suite " .. room.Id)
	return true
end

function RoomService:ToggleDoor(player, roomId)
	local room = self.Rooms[roomId]
	if not room then return false end
	if room.Occupant ~= player then
		self.StateEvent:FireClient(player, "Notice", "This suite is private.")
		return false
	end
	self:_setDoor(room, not room.Open)
	return true
end

function RoomService:Checkout(player)
	local room = self:_currentRoom(player)
	if not room then return false end
	room.Occupant = nil
	self:_setDoor(room, false)
	self:_send(player)
	self.StateEvent:FireClient(player, "Notice", "You checked out.")
	return true
end

function RoomService:CycleTheme(player, roomId)
	local room = self.Rooms[roomId]
	if not room or room.Occupant ~= player or not room.Decor then return false end
	local profile = self.DataService:Get(player)
	if not profile then return false end
	local order = {"Default","Blush","Pearl","Lavender","Ocean"}
	local index = table.find(order, profile.RoomTheme) or 1
	profile.RoomTheme = order[index % #order + 1]
	room.Decor.Color = Config.RoomThemes[profile.RoomTheme].Color
	self.StateEvent:FireClient(player, "Notice", "Suite theme: " .. profile.RoomTheme)
	self:_send(player)
	return true
end

function RoomService:PlayerRemoving(player)
	self:Checkout(player)
end

return RoomService
]=], 2),
["ServerScriptService/Modules/BoutiqueService"]=string.sub([=[!-- Clothing must be custom/uploaded Roblox Accessory instances (prefer R15 layered clothing).
-- Missing art cannot be purchased. No imitation clothing attached by code.
local RS=game:GetService("ReplicatedStorage")
local Config=require(RS:WaitForChild("HotelConfig"))
local Boutique={}
Boutique.__index=Boutique

function Boutique.new(data, event)
	return setmetatable({Data=data, Event=event}, Boutique)
end

local function templateFor(id)
	local root=RS:FindFirstChild("RoyalAssets")
	local catalog=root and root:FindFirstChild("Clothing")
	local asset=catalog and catalog:FindFirstChild(id)
	if asset and asset:IsA("Accessory") then return asset end
end

function Boutique:Catalog(player)
	local list={}
	for _, item in ipairs(Config.Clothing) do
		table.insert(list,{Id=item.Id,Name=item.Name,Price=item.Price,Slot=item.Slot,Ready=templateFor(item.Id)~=nil})
	end
	self.Event:FireClient(player,"BoutiqueCatalog",list)
end

function Boutique:Buy(player,id)
	local item=Config.GetClothing(id)
	local profile=self.Data:Get(player)
	if not item or not profile then return false,"Item unavailable" end
	if profile.Owned[id] then return false,"Already owned" end
	if not templateFor(id) then return false,"This item needs its 3D asset uploaded" end
	if profile.Diamonds < item.Price then return false,"Not enough diamonds" end
	if not self.Data:AddDiamonds(player,-item.Price) then return false,"Purchase failed" end
	profile.Owned[id]=true
	self.Event:FireClient(player,"BoutiqueOwnership",profile.Owned)
	return true,"Purchased "..item.Name
end

function Boutique:Apply(player)
	local profile=self.Data:Get(player)
	local character=player.Character
	local humanoid=character and character:FindFirstChildOfClass("Humanoid")
	if not profile or not humanoid then return end
	for _, child in ipairs(character:GetChildren()) do
		if child:IsA("Accessory") and child:GetAttribute("ERH_Boutique") then child:Destroy() end
	end
	for slot,id in pairs(profile.Equipped) do
		local item=Config.GetClothing(id)
		local template=templateFor(id)
		if slot~="Pet" and item and item.Slot==slot and profile.Owned[id] and template then
			local asset=template:Clone()
			asset:SetAttribute("ERH_Boutique",true)
			humanoid:AddAccessory(asset)
		end
	end
end

function Boutique:Equip(player,id)
	local profile=self.Data:Get(player)
	if not profile then return false,"No profile" end
	if id=="" then
		profile.Equipped={}
		self:Apply(player)
		self.Event:FireClient(player,"BoutiqueEquipped",profile.Equipped)
		return true,"Outfit cleared"
	end
	local item=Config.GetClothing(id)
	if not item or not profile.Owned[id] or not templateFor(id) then return false,"Item is not owned or ready" end
	if profile.Equipped[item.Slot]==id then profile.Equipped[item.Slot]=nil
	else profile.Equipped[item.Slot]=id end
	self:Apply(player)
	self.Event:FireClient(player,"BoutiqueEquipped",profile.Equipped)
	return true,"Wardrobe updated"
end

function Boutique:Sync(player)
	local profile=self.Data:Get(player)
	if profile then
		self:Catalog(player)
		self.Event:FireClient(player,"BoutiqueOwnership",profile.Owned)
		self.Event:FireClient(player,"BoutiqueEquipped",profile.Equipped)
	end
end
return Boutique
]=], 2),
["ServerScriptService/Modules/AmenityService"]=string.sub([=[!-- Bind interactive hotel amenities to appropriately named BaseParts in RoyalHotelMap.
-- Place polished furniture yourself; only the gameplay wiring is automatic.
local Amenity={}
Amenity.__index=Amenity

local function makePrompt(part,action,object)
	local prompt=part:FindFirstChildWhichIsA("ProximityPrompt") or Instance.new("ProximityPrompt")
	prompt.ActionText=action
	prompt.ObjectText=object
	prompt.MaxActivationDistance=10
	prompt.HoldDuration=0
	prompt.RequiresLineOfSight=false
	prompt.Parent=part
	return prompt
end

local function giveSnack(player,displayName,color)
	local backpack=player:FindFirstChildOfClass("Backpack")
	if not backpack then return end
	local existing=backpack:FindFirstChild(displayName)
	if existing then return end
	local tool=Instance.new("Tool")
	tool.Name=displayName
	tool.RequiresHandle=true
	tool.CanBeDropped=false
	local handle=Instance.new("Part")
	handle.Name="Handle"
	handle.Size=Vector3.new(0.7,0.7,0.7)
	handle.Shape=Enum.PartType.Ball
	handle.Color=color
	handle.Material=Enum.Material.SmoothPlastic
	handle.CanCollide=false
	handle.Parent=tool
	tool.Activated:Connect(function()
		local humanoid=player.Character and player.Character:FindFirstChildOfClass("Humanoid")
		if humanoid then humanoid.Health=math.min(humanoid.MaxHealth,humanoid.Health+5) end
		tool:Destroy()
	end)
	tool.Parent=backpack
end

function Amenity.new(event) return setmetatable({Event=event},Amenity) end

function Amenity:BindWorld(map)
	for _,p in ipairs(map:GetDescendants()) do
		if not p:IsA("BasePart") then continue end
		local kind=p:GetAttribute("Amenity")
		if kind=="Cafe" or kind=="Restaurant" then
			local prompt=makePrompt(p,"Order","Royal "..kind)
			prompt.Triggered:Connect(function(player)
				giveSnack(player,kind=="Cafe" and "Rose Cupcake" or "Royal Dessert",kind=="Cafe" and Color3.fromRGB(250,173,211) or Color3.fromRGB(244,224,179))
				self.Event:FireClient(player,"Notice","Your "..kind.." order is ready")
			end)
		elseif kind=="Spa" then
			local prompt=makePrompt(p,"Relax","Royal Spa")
			prompt.Triggered:Connect(function(player)
				local humanoid=player.Character and player.Character:FindFirstChildOfClass("Humanoid")
				if humanoid then humanoid.Health=math.min(humanoid.MaxHealth,humanoid.Health+20) end
				self.Event:FireClient(player,"Notice","Spa treatment complete")
			end)
		elseif kind=="Ballroom" then
			local prompt=makePrompt(p,"Dance","Royal Ballroom")
			prompt.Triggered:Connect(function(player)
				self.Event:FireClient(player,"Notice","Use your Roblox dance emote to join the ball")
			end)
		end
	end
end
return Amenity
]=], 2),
["ServerScriptService/Modules/PetModelFactory"]=string.sub([=[!-- The approved meshes go in ReplicatedStorage/RoyalAssets/Pets/<petId> as Models.
-- Without art, an elegant glowing orb is used as an explicitly temporary test avatar.
local RS=game:GetService("ReplicatedStorage")
local Factory={}

local function fallback(petDef)
	local model=Instance.new("Model")
	model.Name=petDef.Name .. " (ART PLACEHOLDER)"
	local root=Instance.new("Part")
	root.Name="Primary"
	root.Shape=Enum.PartType.Ball
	root.Size=Vector3.new(1.35,1.65,1.35)
	root.Material=Enum.Material.Glass
	root.Color=petDef.Color
	root.Transparency=0.16
	root.Anchored=true
	root.CanCollide=false
	root.CanTouch=false
	root.CanQuery=false
	root.Parent=model
	local light=Instance.new("PointLight")
	light.Color=petDef.Color; light.Range=8; light.Brightness=0.8; light.Parent=root
	local sparkle=Instance.new("Sparkles")
	sparkle.SparkleColor=petDef.Color; sparkle.Parent=root
	local label=Instance.new("BillboardGui")
	label.Name="PlaceholderLabel"
	label.Size=UDim2.fromOffset(170,35)
	label.StudsOffset=Vector3.new(0,1.6,0)
	label.AlwaysOnTop=false
	label.Parent=root
	local txt=Instance.new("TextLabel")
	txt.Size=UDim2.fromScale(1,1)
	txt.BackgroundTransparency=1
	txt.Text=petDef.Name .. " • TEST ART"
	txt.Font=Enum.Font.GothamBold
	txt.TextSize=13
	txt.TextColor3=Color3.fromRGB(255,245,255)
	txt.TextStrokeTransparency=0.2
	txt.Parent=label
	model.PrimaryPart=root
	return model
end

function Factory.CreatePetModel(petDef)
	local assets=RS:FindFirstChild("RoyalAssets")
	local pets=assets and assets:FindFirstChild("Pets")
	local template=pets and pets:FindFirstChild(petDef.Id)
	if not template or not template:IsA("Model") then return fallback(petDef) end
	local model=template:Clone()
	model.Name=petDef.Name
	local first=model:FindFirstChildWhichIsA("BasePart",true)
	if not first then model:Destroy(); return fallback(petDef) end
	model.PrimaryPart=model.PrimaryPart or first
	for _, obj in ipairs(model:GetDescendants()) do
		if obj:IsA("Script") or obj:IsA("LocalScript") or obj:IsA("ModuleScript") then
			obj:Destroy()
		elseif obj:IsA("BasePart") then
			obj.Anchored=true
			obj.CanCollide=false
			obj.CanTouch=false
			obj.CanQuery=false
		end
	end
	return model
end
return Factory
]=], 2)
}
local function findPath(path)
    local object = game
    for token in string.gmatch(path, "[^/]+") do
        object = object:FindFirstChild(token)
        if not object then return nil end
    end
    return object
end
local function normalize(source) return string.gsub(source, "\r\n", "\n") end
for path, source in pairs(BASELINE) do
    local object = findPath(path)
    if not object or not object:IsA("LuaSourceContainer") then fail("Missing protected script: " .. path)
    elseif normalize(object.Source) == normalize(source) then pass("Original source unchanged: " .. path)
    else fail("Source differs from uploaded Stage 3.1 original: " .. path .. "; inspect the difference before using this milestone") end
end
local config = findPath("ReplicatedStorage/HotelConfig")
if config and config:IsA("ModuleScript") then
    if string.match(config.Source, "RoyalEggPrice%s*=%s*750") then pass("RoyalEggPrice remains 750 diamonds") else fail("RoyalEggPrice = 750 not found") end
    if string.match(config.Source, 'DataStoreName%s*=%s*"ERH_Stage3_TEST_v1"') then pass("Original DataStoreName retained") else fail("DataStoreName differs from original") end
    if string.match(config.Source, "EnableLegacyReadMigration%s*=%s*false") then pass("Original legacy migration setting retained") else fail("Legacy migration differs from original") end
end
local maps = {}
for _, child in ipairs(WS:GetChildren()) do
    if child.Name == "RoyalHotelMap" then table.insert(maps, child) end
end
if #maps ~= 1 then fail("Expected one permanent direct Workspace.RoyalHotelMap; found " .. #maps) end
local map = maps[1]
if map then
    local params = RaycastParams.new()
    params.FilterType = Enum.RaycastFilterType.Exclude
    params.FilterDescendantsInstances = {}
    params.RespectCanCollide = true
    for _, name in ipairs({"LobbySpawn", "SpaSpawn", "CafeSpawn", "PoolSpawn", "BallroomSpawn", "NurserySpawn", "BoutiqueSpawn"}) do
        local point = map:FindFirstChild(name)
        local duplicates = 0
        for _, child in ipairs(map:GetChildren()) do if child.Name == name then duplicates += 1 end end
        if not point or not point:IsA("BasePart") or duplicates ~= 1 then fail("Need exactly one DIRECT BasePart: " .. name)
        else
            if point.Anchored and not point.CanCollide and point.Transparency == 1 then pass("Teleport marker flags: " .. name)
            else fail("Teleport marker must be anchored, invisible, noncolliding: " .. name) end
            local hit = WS:Raycast(point.Position + Vector3.new(0, 1, 0), Vector3.new(0, -20, 0), params)
            if hit and hit.Normal.Y > 0.6 and hit.Distance <= 7 then pass("Colliding floor within 7 studs below " .. name .. ": " .. hit.Instance:GetFullName())
            else fail("No nearby upward floor below " .. name .. "; do not Play until placement is checked") end
        end
    end
    local rooms = map:FindFirstChild("Rooms")
    if not rooms or not rooms:IsA("Folder") then fail("Need direct Rooms Folder")
    else
        local ids, n = {}, 0
        for _, room in ipairs(rooms:GetChildren()) do
            if room:IsA("Model") then
                n += 1
                local id, wing = room:GetAttribute("RoomId"), room:GetAttribute("Wing")
                if type(id) ~= "string" or id == "" or ids[id] then fail("Missing/duplicate RoomId on " .. room.Name) else ids[id] = true end
                if wing ~= "Princess" and wing ~= "Mermaid" and wing ~= "Fairy" then fail("Invalid Wing on " .. room.Name) end
                for _, name in ipairs({"Door", "ClaimPrompt", "InteriorSpawn"}) do
                    local part = room:FindFirstChild(name)
                    if not part or not part:IsA("BasePart") then fail("Room " .. room.Name .. " needs direct BasePart " .. name) end
                end
            end
        end
        if n == 0 then fail("No claimable room models") else pass("Claimable room contract present: " .. n .. " rooms") end
        if n < 9 then warning("This milestone retains the original test rooms. Nine finished luxury suites are not delivered.") end
    end
    local diamondFolder = map:FindFirstChild("DiamondSpawns")
    local diamondCount = 0
    if not diamondFolder or not diamondFolder:IsA("Folder") then fail("Need direct DiamondSpawns Folder")
    else
        for _, part in ipairs(diamondFolder:GetChildren()) do
            if part:IsA("BasePart") then
                diamondCount += 1
                local kind, area = part:GetAttribute("DiamondType"), part:GetAttribute("Area")
                if kind ~= "Pink" and kind ~= "Blue" and kind ~= "Purple" and kind ~= "Gold" then fail("Bad DiamondType at " .. part.Name) end
                if type(area) ~= "string" or area == "" then fail("Missing Area at " .. part.Name) end
            end
        end
        if diamondCount == 0 then fail("No diamond spawn markers") else pass("Diamond marker attributes: " .. diamondCount .. " markers") end
    end
    local nurseryCount, meshCount, partCount = 0, 0, 0
    local amenities = {Cafe = 0, Restaurant = 0, Spa = 0, Ballroom = 0}
    for _, part in ipairs(map:GetDescendants()) do
        if part:IsA("BasePart") then
            partCount += 1
            if part:IsA("MeshPart") then
                meshCount += 1
                if part.MeshId == "" or part.MeshId == "rbxassetid://0" then fail("Mesh has no uploaded asset: " .. part:GetFullName()) end
            end
            local kind = part:GetAttribute("Amenity")
            if amenities[kind] then amenities[kind] += 1 end
            if part:GetAttribute("Interaction") == "OpenNursery" then
                nurseryCount += 1
                if not part:FindFirstChildWhichIsA("ProximityPrompt") then fail("Nursery requires existing ProximityPrompt: " .. part:GetFullName()) end
            end
        end
    end
    if nurseryCount > 0 then pass("Original OpenNursery prompt preserved") else fail("OpenNursery interaction missing") end
    for kind, count in pairs(amenities) do
        if count == 0 then warning(kind .. " amenity marker absent in retained map; this front-slice milestone does not build that amenity")
        else pass("Existing " .. kind .. " interaction markers: " .. count) end
    end
    local slice = map:FindFirstChild("ERH_FrontSlice")
    if not slice then fail("ERH_FrontSlice is not installed")
    else
        pass("Additive front slice present")
        if slice:FindFirstChild("ArchitectureMeshes") and meshCount > 0 then pass("Real imported MeshParts present: " .. meshCount) else fail("No imported architecture meshes") end
        if slice:FindFirstChild("WalkableCollision") then pass("Separate movement collision present") else fail("Movement collision missing") end
        if slice:GetAttribute("ERH_CreatedOriginalFallback") then warning("Fallback platform remains behind the foyer, connected by a temporary development bridge. It is not finished amenity art.") end
    end
    pass("Map contains " .. partCount .. " BaseParts; performance still requires device profiling")
    warning("Restaurant has no original Royal Map button. No Restaurant script patch is included in this milestone.")
end
local assets = game:GetService("ReplicatedStorage"):FindFirstChild("RoyalAssets")
if not assets or not assets:FindFirstChild("Pets") then warning("Original custom pet assets absent; existing pet-orb fallback retained") end
if not assets or not assets:FindFirstChild("Clothing") then warning("Original clothing Accessory assets absent; boutique purchase limitation retained") end
print(string.format("[ERH SUMMARY] %d PASS / %d WARN / %d FAIL", passes, warnings, failures))
print("[ERH LIMIT] Read-only source/structure checks only. Character movement, UI interactions, mesh upload appearance, mobile frame time and saved DataStore persistence require the Studio checklist.")
