-- EDIT MODE ONLY. Reverses only the documented front-slice installation.
-- This leaves a reproduced original fallback map in Edit mode if one was created.
local WS = game:GetService("Workspace")
assert(not game:GetService("RunService"):IsRunning(), "Stop Play before rollback")
local map = WS:FindFirstChild("RoyalHotelMap")
local slice = map and map:FindFirstChild("ERH_FrontSlice")
assert(slice, "No ERH_FrontSlice to roll back")
local records = slice:FindFirstChild("_RollbackRecords")
assert(records, "Rollback records missing; do not remove the model until you inspect it")
local lobbyRef = records:FindFirstChild("LobbySpawn")
assert(lobbyRef and lobbyRef.Value, "Original LobbySpawn reference missing")
assert(lobbyRef.Value.CFrame == lobbyRef:GetAttribute("InstalledCFrame"), "LobbySpawn was moved after installation; inspect your change before rollback")
local artRef = records:FindFirstChild("ImportedArt")
assert(artRef and artRef.Value, "Imported art reference missing")
game:GetService("ChangeHistoryService"):SetWaypoint("Before ERH rollback")
for _, ref in ipairs(records:GetChildren()) do
    if ref:IsA("ObjectValue") and ref.Value and ref:GetAttribute("OriginalCFrame") then
        local object = ref.Value
        object.CFrame = ref:GetAttribute("OriginalCFrame")
        object.Size = ref:GetAttribute("OriginalSize")
        object.Anchored = ref:GetAttribute("OriginalAnchored")
        object.CanCollide = ref:GetAttribute("OriginalCanCollide")
        object.CanTouch = ref:GetAttribute("OriginalCanTouch")
        object.CanQuery = ref:GetAttribute("OriginalCanQuery")
        object.CastShadow = ref:GetAttribute("OriginalCastShadow")
        object.Transparency = ref:GetAttribute("OriginalTransparency")
        object.Color = ref:GetAttribute("OriginalColor")
        object.Material = Enum.Material[ref:GetAttribute("OriginalMaterial")]
    end
end
local art = artRef.Value
art.Name = "ERH_ImportedMeshes"
art.Parent = WS
slice:Destroy()
game:GetService("ChangeHistoryService"):SetWaypoint("ERH rollback complete")
print("[ERH ROLLBACK] Imported mesh group restored to Workspace; LobbySpawn restored; front-slice helpers removed. Original Stage 3.1 scripts, saved data, other map content and SpawnLocation untouched.")
