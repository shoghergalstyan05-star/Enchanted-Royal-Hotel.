"""Execute the actual placement helper under Luau; Roblox services are mocked.

These verify placement arithmetic and failure behavior, not Studio physics.
"""
from pathlib import Path
import os
import subprocess
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
LUAU = Path(os.environ.get("ERH_LUAU", "/workspace/.erh-tools/bin/luau"))
HELPER = ROOT / "src/roblox/adaptive_placement.lua"

MOCKS = r'''
local Vector3 = {}
local vectorMeta = {}
function Vector3.new(x, y, z)
    return table.freeze(setmetatable({X=x, Y=y, Z=z}, vectorMeta))
end
function vectorMeta.__div(v, n) return Vector3.new(v.X/n, v.Y/n, v.Z/n) end
local function frame(x, y, z, angle)
    local c, s = math.cos(angle or 0), math.sin(angle or 0)
    return table.freeze({
        Position = Vector3.new(x,y,z),
        PointToWorldSpace = function(self, v)
            return Vector3.new(x+c*v.X+s*v.Z, y+v.Y, z-s*v.X+c*v.Z)
        end,
    })
end
local imported = table.freeze({Name="ERH_ImportedMeshes"})
local function part(name, x, y, z, sx, sy, sz, angle, isImported)
    local cf = frame(x,y,z,angle)
    return table.freeze({
        Name=name, CFrame=cf, Position=cf.Position, Size=Vector3.new(sx,sy,sz),
        IsA=function(self, class) return class == "BasePart" end,
        IsDescendantOf=function(self, ancestor) return isImported == true and ancestor == imported end,
    })
end
local lobby = part("LobbySpawn",0,6,40,2,1,2)
local diamondFolder = table.freeze({Name="DiamondSpawns"})
local oldParts = {part("OldFloor",5,0,0,10,1,10), lobby}
local rayCalls = 0
local rayOrigin, rayDirection, rayParams
local ground = {Position=Vector3.new(0,2.75,40), Normal=Vector3.new(0,1,0)}
local WS = table.freeze({Raycast=function(self, origin, direction, params)
    rayCalls += 1
    rayOrigin, rayDirection, rayParams = origin, direction, params
    return ground
end})
local RaycastParams = table.freeze({new=function() return {} end})
local Enum = table.freeze({RaycastFilterType=table.freeze({Exclude="Exclude"})})
local DATA = {chunks={{center_roblox={0,2,0},size_roblox={10,4,10}}}, boxes={}}
local madeFallback = false
local OFFSET = Vector3.new(0,0.5,180)
local map = table.freeze({LobbySpawn=lobby,
    GetDescendants=function() return oldParts end,
    FindFirstChild=function(self, name)
        if name == "LobbySpawn" then return lobby end
        if name == "DiamondSpawns" then return diamondFolder end
        return nil
    end,
})
local function near(actual, expected)
    assert(math.abs(actual-expected) < 1e-7, tostring(actual).." differs from "..tostring(expected))
end
'''


class AdaptivePlacementTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if not LUAU.is_file():
            raise RuntimeError(f"Official Luau CLI unavailable: {LUAU}")
        cls.helper = HELPER.read_text()

    def run_helper(self, setup, checks):
        program = MOCKS + "\n" + setup + "\nlocal function applyPlacement()\n" + self.helper + "\nend\n" + checks
        with tempfile.TemporaryDirectory(prefix="erh-placement-") as directory:
            path = Path(directory) / "placement.luau"
            path.write_text(program)
            result = subprocess.run([str(LUAU), str(path)], capture_output=True, text=True, timeout=10)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_rotated_old_part_uses_world_corner_footprint(self):
        self.run_helper(
            'oldParts={part("Rotated",10,0,0,4,2,8,math.pi/4),lobby}',
            'applyPlacement(); near(OFFSET.X,10+6/math.sqrt(2)+20+5)',
        )

    def test_imported_subtree_does_not_expand_existing_map(self):
        self.run_helper(
            'table.insert(oldParts,part("ImportedChunk",1000,0,0,100,10,100,0,true))',
            'applyPlacement(); near(OFFSET.X,35)',
        )

    def test_rotated_collision_beyond_mesh_sets_twenty_stud_gap(self):
        self.run_helper(
            'DATA.boxes={{center={-2,0,0},size={6,10,1},yaw_degrees=90}}',
            'applyPlacement(); near(OFFSET.X,37); near((OFFSET.X-7)-10,20)',
        )

    def test_ground_alignment_and_existing_lobby_z_are_retained(self):
        self.run_helper('', r'''
            applyPlacement()
            near(OFFSET.Y,2.75); near(OFFSET.Z,55)
            near(OFFSET.Z-15,lobby.Position.Z)
            assert(rayOrigin == lobby.Position)
            near(rayDirection.Y,-1024)
            assert(rayParams.RespectCanCollide == true)
            assert(rayParams.FilterType == Enum.RaycastFilterType.Exclude)
            assert(table.find(rayParams.FilterDescendantsInstances, imported))
            assert(table.find(rayParams.FilterDescendantsInstances, lobby))
            assert(table.find(rayParams.FilterDescendantsInstances, diamondFolder))
            near(lobby.Position.X,0); near(lobby.Position.Y,6); near(lobby.Position.Z,40)
        ''')

    def test_no_ground_fails_without_changing_offset_or_map(self):
        self.run_helper('ground=nil', r'''
            local priorOffset=OFFSET
            local ok, message=pcall(applyPlacement)
            assert(not ok and string.find(message,"No level collidable floor",1,true))
            assert(OFFSET == priorOffset)
            near(lobby.Position.Y,6)
        ''')

    def test_sloped_ground_fails_without_changing_offset_or_map(self):
        self.run_helper('ground.Normal=Vector3.new(0.6,0.8,0)', r'''
            local priorOffset=OFFSET
            local ok, message=pcall(applyPlacement)
            assert(not ok and string.find(message,"No level collidable floor",1,true))
            assert(OFFSET == priorOffset)
            near(lobby.Position.Y,6)
        ''')

    def test_original_fallback_uses_fixed_offset_without_raycasts(self):
        self.run_helper('madeFallback=true; ground=nil; oldParts={}', r'''
            applyPlacement()
            near(OFFSET.X,0); near(OFFSET.Y,0.5); near(OFFSET.Z,180)
            assert(rayCalls == 0)
        ''')

    def test_empty_existing_map_fails_before_raycasts(self):
        self.run_helper('oldParts={}', r'''
            local priorOffset=OFFSET
            local ok, message=pcall(applyPlacement)
            assert(not ok and string.find(message,"no measurable parts",1,true))
            assert(rayCalls == 0 and OFFSET == priorOffset)
        ''')

    def test_generated_installer_has_helper_before_live_commit(self):
        installer = (ROOT / "build/InstallFrontSlice_BesideExistingMap.lua").read_text()
        self.assertIn(self.helper, installer)
        helper_at = installer.index(self.helper)
        commit_at = installer.index("-- All contract checks and local assembly have passed")
        self.assertLess(helper_at, commit_at)
        self.assertLess(helper_at, installer.index('local slice = Instance.new("Model")'))


if __name__ == "__main__":
    unittest.main()
