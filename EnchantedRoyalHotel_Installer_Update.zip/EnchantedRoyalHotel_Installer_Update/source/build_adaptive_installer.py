#!/usr/bin/env python3
"""Produce an isolated Studio installer update without changing the original package."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def build():
    original = (ROOT / "build/InstallFrontSlice.lua").read_text()
    placement = (ROOT / "src/roblox/adaptive_placement.lua").read_text()
    anchor = 'local slice = Instance.new("Model")'
    assert original.count(anchor) == 1
    updated = original.replace(anchor, placement + "\n" + anchor, 1)
    updated = updated.replace(
        "-- Enchanted Royal Hotel: first milestone installer, EDIT MODE ONLY.",
        "-- Enchanted Royal Hotel: beside-existing-map installer, EDIT MODE ONLY.", 1)
    updated = updated.replace(
        "-- Paste the complete generated build/InstallFrontSlice.lua into Studio Command Bar.",
        "-- Paste this entire file into the Edit-mode Command Bar and click its Run button.", 1)
    import_anchor = 'local imported = WS:FindFirstChild("ERH_ImportedMeshes")'
    assert updated.count(import_anchor) == 1
    duplicate_guard = '''local importGroupCount = 0
for _, child in ipairs(WS:GetChildren()) do
    if child.Name == "ERH_ImportedMeshes" then importGroupCount += 1 end
end
assert(importGroupCount == 1, "Expected exactly one ERH_ImportedMeshes model directly under Workspace; resolve duplicate imports before installation")
'''
    updated = updated.replace(import_anchor, duplicate_guard + import_anchor, 1)
    warning = "Existing map retained. Check that the staged front slice at Z=180 does not overlap your current art; its rear portal needs an authored connection to your map."
    assert updated.count(warning) == 1
    updated = updated.replace(warning, "Existing map retained. The new section is staged beside its measured parts. A walk connection to the old map still needs authoring; existing Royal Map destinations are retained.")
    target = ROOT / "build/InstallFrontSlice_BesideExistingMap.lua"
    target.write_text(updated)
    return target


if __name__ == "__main__":
    print(build())
