-- Existing-map placement only. Reads the old map; never moves its parts.
local function chooseExistingMapOffset(map, imported, data)
    local oldMaxX, newMinX = -math.huge, math.huge
    local oldPartCount = 0
    for _, part in ipairs(map:GetDescendants()) do
        if part:IsA("BasePart") and not part:IsDescendantOf(imported) then
            oldPartCount += 1
            for x = -1, 1, 2 do for y = -1, 1, 2 do for z = -1, 1, 2 do
                local corner = part.CFrame:PointToWorldSpace(Vector3.new(x * part.Size.X, y * part.Size.Y, z * part.Size.Z) / 2)
                oldMaxX = math.max(oldMaxX, corner.X)
            end end end
        end
    end
    assert(oldPartCount > 0, "Existing map has no measurable parts; no changes made")
    for _, chunk in ipairs(data.chunks) do
        newMinX = math.min(newMinX, chunk.center_roblox[1] - chunk.size_roblox[1] / 2)
    end
    for _, box in ipairs(data.boxes) do
        local yaw = math.rad(box.yaw_degrees or 0)
        local halfWidth = (math.abs(math.cos(yaw)) * box.size[1] + math.abs(math.sin(yaw)) * box.size[2]) / 2
        newMinX = math.min(newMinX, box.center[1] - halfWidth)
    end
    assert(newMinX > -math.huge and newMinX < math.huge, "New model bounds are invalid; no changes made")

    local excluded = {imported}
    for _, name in ipairs({"LobbySpawn", "SpaSpawn", "CafeSpawn", "PoolSpawn", "BallroomSpawn", "NurserySpawn", "BoutiqueSpawn", "DiamondSpawns"}) do
        local marker = map:FindFirstChild(name)
        if marker then table.insert(excluded, marker) end
    end
    local params = RaycastParams.new()
    params.FilterType = Enum.RaycastFilterType.Exclude
    params.FilterDescendantsInstances = excluded
    params.RespectCanCollide = true
    local lobby = map.LobbySpawn
    local ground = WS:Raycast(lobby.Position, Vector3.new(0, -1024, 0), params)
    assert(ground and ground.Normal.Y >= 0.9, "No level collidable floor found below LobbySpawn; no changes made")
    local result = Vector3.new(oldMaxX + 20 - newMinX, ground.Position.Y, lobby.Position.Z + 15)
    print("[ERH PLACEMENT] New section offset:", result, "with a 20-stud gap beyond the old map's parts")
    return result
end

if not madeFallback then OFFSET = chooseExistingMapOffset(map, imported, DATA) end
